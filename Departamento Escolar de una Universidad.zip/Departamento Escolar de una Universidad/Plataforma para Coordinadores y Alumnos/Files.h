

#pragma once

char CC_Archi[] = "CordiCarrLista.txt";
char szFileName[MAX_PATH] = "";

char file0[_MAX_PATH]; //file0 guarda la direccion donde estan ubicados estos archivos
char file[_MAX_PATH] = { "UANL_logoBlancoModify.bmp" };
char file2[_MAX_PATH] = { "FCFM_logoBlanco.bmp" };
char file3[_MAX_PATH] = { "UsersNames.txt " };
char file4[_MAX_PATH] = { "Foto_Coordi_General.bmp " };

char file11[_MAX_PATH] = { "Alum_A_Mate.bmp" };
char file12[_MAX_PATH] = { "Mate_A_Alumbmp.bmp" };

char file5[_MAX_PATH]; //foto

char a_file7[_MAX_PATH]; //auxiliar
char a_file8[_MAX_PATH]; //auxiliar
char a_file9[_MAX_PATH]; //auxiliar
char a_file10[_MAX_PATH]; //auxiliar
char a_file12[_MAX_PATH]; //auxiliar
char a_file11[_MAX_PATH]; //auxiliar


char file6[]="CordiNamesSave.txt"; //carreras y coordinadores
char file7[] = "ListaAlumnos.txt";
char file8[] = "ListaSemestres.txt";
char file9[] = "ListaMaterias.txt";
char file10[] = "ListaCalif.txt";

char Heapsort []  = "A_Heapsort.txt";
char Quicksort[] = "A_Quicksort.txt";
int a = 0;
bool edit = false;





